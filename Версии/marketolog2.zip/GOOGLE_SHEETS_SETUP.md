# Как сохранять заявки в Google Таблицу (Вечная база данных)

Так как у нас нет своего сервера, мы превратим **Google Таблицу** в нашу базу данных. Это бесплатно и надежно.

## 1. Подготовка Таблицы
1.  Создайте новую Google Таблицу: [sheets.new](https://sheets.new)
2.  Назовите её, например, **"Заявки Antigravity"**.
3.  В первой строке напишите заголовки столбцов:
    *   **A1**: `Дата`
    *   **B1**: `Имя`
    *   **C1**: `Email`
    *   **D1**: `Telegram`

## 2. Создание Скрипта
1.  В таблице нажмите **Расширения (Extensions)** -> **Apps Script**.
2.  Удалите весь код, который там есть (`function myFunction()...`).
3.  Вставьте этот код:

```javascript
function doPost(e) {
  var sheet = SpreadsheetApp.getActiveSpreadsheet().getActiveSheet();
  var data = e.parameter;
  
  sheet.appendRow([
    new Date().toLocaleString(), // А — Дата
    data.name,                   // B — Имя
    data.email,                  // C — Email
    data.telegram                // D — Telegram
  ]);
  
  return ContentService.createTextOutput(JSON.stringify({"result":"success", "row": sheet.getLastRow()}))
    .setMimeType(ContentService.MimeType.JSON);
}
```

4.  Нажмите иконку дискеты **(Сохранить)**. Назовите проект "Payment Save".

## 3. Публикация (Самое важное!)
1.  Справа сверху нажмите синюю кнопку **Начать развертывание (Deploy)** -> **Новое развертывание (New deployment)**.
2.  Нажмите на шестеренку (Select type) -> **Веб-приложение (Web app)**.
3.  Заполните поля:
    *   **Описание**: `v1`
    *   **Запуск от имени**: `Я (Me)`
    *   **У кого есть доступ (Who has access)**: **ВСЕ (Anyone)** <--- **ЭТО ОЧЕНЬ ВАЖНО!!!** (Иначе сайт не сможет отправлять данные).
4.  Нажмите **Начать развертывание (Deploy)**.
5.  Google попросит разрешение (Authorize access). Выберите свой аккаунт -> **Advanced** -> **Go to Payment Save (unsafe)** -> **Allow**.
6.  Вам выдадут **URL веб-приложения** (длинная ссылка, заканчивается на `/exec`).
7.  **Скопируйте эту ссылку!**

## 4. Вставка на сайт
Откройте файл `assets/js/payment.js` и вставьте эту ссылку в переменную `GOOGLE_SCRIPT_URL`.
