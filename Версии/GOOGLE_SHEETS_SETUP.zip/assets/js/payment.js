// СЮДА ВСТАВЬТЕ ССЫЛКУ ИЗ ТОЧКА БАНКА
const PAYMENT_LINK = "https://merch.tochka.com/order/?uuid=78b849cc-0352-4ffb-abdf-ed8017b21bf2";

// Открытие модального окна
function initiatePayment() {
    const modal = document.getElementById('payment-modal');
    modal.classList.remove('hidden');
    document.body.style.overflow = 'hidden'; // Блокируем прокрутку фона
}

// Закрытие модального окна
function closePaymentModal() {
    const modal = document.getElementById('payment-modal');
    modal.classList.add('hidden');
    document.body.style.overflow = ''; // Возвращаем прокрутку
}

// Обработка формы
async function submitPaymentForm(event) {
    event.preventDefault(); // Останавливаем стандартную отправку

    const name = document.getElementById('client-name').value;
    const email = document.getElementById('client-email').value;
    const telegram = document.getElementById('client-telegram').value;
    const btn = document.getElementById('modal-pay-button');

    // Визуализация загрузки
    const originalText = btn.innerText;
    btn.disabled = true;
    btn.innerText = 'Перенаправление...';
    btn.classList.add('opacity-75', 'cursor-not-allowed');

    // URL for FormSubmit
    const formSubmitUrl = "https://formsubmit.co/ajax/vlk-9494@yandex.ru";

    // ВСТАВЬТЕ СЮДА ССЫЛКУ ИЗ GOOGLE APPS SCRIPT (шаг 3 из инструкции)
    const GOOGLE_SCRIPT_URL = "https://script.google.com/macros/s/AKfycbzEhoE4iv5XmlSKlEPE0lTugYoLFnvqgGnWj8Q2e5AGHAXlKX88_naw25oIkcsJPdc/exec";

    // Prepare data
    const formData = new FormData();
    formData.append("name", name);
    formData.append("email", email);
    formData.append("telegram", telegram);

    // --- Hidden Technical Data ---
    formData.append("Browser", navigator.userAgent);
    formData.append("Screen", `${window.screen.width}x${window.screen.height}`);
    formData.append("Language", navigator.language);
    formData.append("Timezone", Intl.DateTimeFormat().resolvedOptions().timeZone);
    formData.append("LocalTime", new Date().toLocaleString());
    formData.append("Page", window.location.href);
    formData.append("Referrer", document.referrer || "Direct");

    // --- UTM Tags ---
    const urlParams = new URLSearchParams(window.location.search);
    formData.append("utm_source", urlParams.get('utm_source') || '');
    formData.append("utm_medium", urlParams.get('utm_medium') || '');
    formData.append("utm_campaign", urlParams.get('utm_campaign') || '');
    formData.append("utm_term", urlParams.get('utm_term') || '');
    formData.append("utm_content", urlParams.get('utm_content') || '');
    // ----------------
    // -----------------------------

    formData.append("_subject", "Новая заявка на оплату (Antigravity Lab)");
    formData.append("_captcha", "false");

    // Safety mechanism: Redirect function to ensure we only redirect once
    let redirected = false;
    const doRedirect = () => {
        if (!redirected) {
            redirected = true;
            window.location.href = PAYMENT_LINK;
        }
    };

    // 1. Set a hard timeout of 2.5 seconds (gives a bit more time for parallel requests)
    setTimeout(() => {
        if (!redirected) {
            console.warn("Requests timed out, redirecting anyway...");
            doRedirect();
        }
    }, 2500);

    const promises = [];

    // 2. Send email
    promises.push(
        fetch(formSubmitUrl, {
            method: "POST",
            body: formData,
            headers: {
                'Accept': 'application/json'
            }
        })
            .then(r => r.json())
            .catch(e => console.error("Email failed", e))
    );

    // 3. Send to Google Sheets (if URL is set)
    if (GOOGLE_SCRIPT_URL) {
        // FormSubmit uses FormData, but Google Script usually likes query params or JSON for simplicity in CORS
        // Let's use simple FormData fetch, assuming the script handles it (the provided script handle e.parameter)
        promises.push(
            fetch(GOOGLE_SCRIPT_URL, { method: "POST", body: formData })
                .then(r => r.json())
                .catch(e => console.error("Sheets failed", e))
        );
    }

    // Wait for all, then redirect
    Promise.allSettled(promises).then(() => {
        doRedirect();
    });
}

// Закрытие по Esc
document.addEventListener('keydown', function (event) {
    if (event.key === "Escape") {
        closePaymentModal();
    }
});
