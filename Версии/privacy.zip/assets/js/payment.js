async function initiatePayment() {
    const payButton = document.getElementById('pay-button');
    const originalText = payButton.innerText;

    // Disable button to prevent double clicks
    payButton.disabled = true;
    payButton.innerText = 'Загрузка...';

    // In a real app, you might want to get the email from a form input
    // For now, we will ask prompt or assume it, or better:
    // If you don't have an email input, you should add one.
    // Let's assume we ask for it or have it from auth.
    // For this demo, let's use a prompt if strictly static, or assume integration later.
    // But better UX: add an email input to the modal or page.

    // Simplest for now: Prompt for Email and Name
    const email = prompt("Пожалуйста, введите ваш Email для получения чека:");
    if (!email) {
        payButton.disabled = false;
        payButton.innerText = originalText;
        return;
    }

    // Tochka Bank API requires a name for the receipt
    const name = prompt("Пожалуйста, введите ваше ФИО:") || "Участник Клуба";

    try {
        const response = await fetch('http://localhost:3000/create-payment', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ email: email, name: name })
        });

        const data = await response.json();

        if (data.url) {
            window.location.href = data.url;
        } else {
            alert('Ошибка: Не удалось получить ссылку на оплату. ' + (data.details || ''));
            console.error(data);
        }
    } catch (error) {
        alert('Ошибка соединения с сервером оплаты.');
        console.error(error);
    } finally {
        payButton.disabled = false;
        payButton.innerText = originalText;
    }
}
